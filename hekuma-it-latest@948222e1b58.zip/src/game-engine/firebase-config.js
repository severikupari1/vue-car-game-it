export const firebaseConfig = {
  apiKey: "AIzaSyCueVhWtAMNmkOsXRCdu5DyfCpbuVPAqqE",
  authDomain: "ambientia-speed-race.firebaseapp.com",
  databaseURL: "https://ambientia-speed-race.firebaseio.com",
  projectId: "ambientia-speed-race",
  storageBucket: "ambientia-speed-race.appspot.com",
  messagingSenderId: "238991134715",
  appId: "1:238991134715:web:9fea4a2b858830cd05855e",
};
