# rekrypeli_front

Frontend to rekrypeli. Setting up the app on local machine is simple:

* npm ci
* npm run serve

And now you have to app running on address: http://localhost:8080
